# FJS-73 — Preamp + EQ estilo consola británica (AU / VST3, macOS)

Controles: Input (-20..+10 dB) · HF shelf ±16 dB (12 kHz) · Mid ±18 dB (OFF/360/700/1.6k/3.2k/4.8k/7.2k)
· LF shelf ±16 dB (OFF/35/60/110/220) · HPF 18 dB/oct (OFF/50/80/160/300) · Ø fase · EQ in/out · Output trim (perilla chica).

## Compilar en tu Mac
    brew install cmake        # una sola vez
    xcode-select --install    # una sola vez
    ./build_mac.sh

Sin Mac a mano: subí la carpeta a un repo de GitHub, andá a Actions > "Build macOS" > Run workflow y bajá FJS-73-mac.zip.

Ventana redimensionable. Doble click en una perilla = valor por defecto. Shift/rueda para ajuste fino.
