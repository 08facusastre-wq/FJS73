#pragma once
#include "PluginProcessor.h"

namespace ui
{
    constexpr int W = 1152;
    constexpr int H = 244;
}

//==============================================================================
// Perilla de hardware dibujada por código (sombras, bisel, moleteado, puntero)
class HardwareKnob : public juce::Slider
{
public:
    enum class Style { Lug, Knurled, Ring, Silver };

    HardwareKnob (Style s, juce::Colour base, float capRadius, float skirtRadius = 0.f);

    void paint (juce::Graphics&) override;
    bool hitTest (int x, int y) override;

    static constexpr int margin = 20;
    int sizeForRadius() const { return (int) std::ceil (std::max (capR, std::max (skirtR, ringOuterR))) * 2 + margin * 2; }

    void setRing (float outerR, float innerR) { ringOuterR = outerR; ringInnerR = innerR; }

private:
    void paintSkirt (juce::Graphics&, juce::Point<float> c);
    void paintCap (juce::Graphics&, juce::Point<float> c, float angle);
    void paintRing (juce::Graphics&, juce::Point<float> c, float angle);

    Style style;
    juce::Colour base;
    float capR, skirtR, ringOuterR = 0.f, ringInnerR = 0.f;
};

//==============================================================================
class KeyButton : public juce::Button
{
public:
    enum class Kind { Phase, EQ };
    explicit KeyButton (Kind k) : juce::Button (k == Kind::Phase ? "Phase" : "EQ"), kind (k) { setClickingTogglesState (true); }
    void paintButton (juce::Graphics&, bool over, bool down) override;
private:
    Kind kind;
};

//==============================================================================
class Panel : public juce::Component
{
public:
    explicit Panel (juce::AudioProcessorValueTreeState&);
    void paint (juce::Graphics&) override;

private:
    juce::Image noise;

    HardwareKnob input   { HardwareKnob::Style::Lug,     juce::Colour (0xff8a1414), 44.f, 66.f };
    HardwareKnob hfGain  { HardwareKnob::Style::Knurled, juce::Colour (0xff9a9da1), 33.f, 66.f };
    HardwareKnob midFreq { HardwareKnob::Style::Ring,    juce::Colour (0xffe9e4d2), 40.f };
    HardwareKnob midGain { HardwareKnob::Style::Knurled, juce::Colour (0xff9a9da1), 38.f };
    HardwareKnob lfFreq  { HardwareKnob::Style::Ring,    juce::Colour (0xffe9e4d2), 40.f };
    HardwareKnob lfGain  { HardwareKnob::Style::Knurled, juce::Colour (0xff9a9da1), 38.f };
    HardwareKnob hpf     { HardwareKnob::Style::Lug,     juce::Colour (0xff1c3470), 42.f, 62.f };
    HardwareKnob output  { HardwareKnob::Style::Silver,  juce::Colour (0xffc4c6c9), 19.f };

    KeyButton phaseBtn { KeyButton::Kind::Phase };
    KeyButton eqBtn    { KeyButton::Kind::EQ };

    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    std::unique_ptr<SA> aIn, aHf, aMidF, aMidG, aLfF, aLfG, aHpf, aOut;
    std::unique_ptr<BA> aPhase, aEq;
};

//==============================================================================
class FJS73Editor : public juce::AudioProcessorEditor
{
public:
    explicit FJS73Editor (FJS73AudioProcessor&);
    void resized() override;

private:
    Panel panel;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (FJS73Editor)
};
