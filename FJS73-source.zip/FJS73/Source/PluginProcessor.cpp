#include "PluginProcessor.h"
#include "PluginEditor.h"

using APF = juce::AudioParameterFloat;
using APC = juce::AudioParameterChoice;
using APB = juce::AudioParameterBool;

static juce::String dbText (float v, int) { return juce::String (v, 1) + " dB"; }

juce::AudioProcessorValueTreeState::ParameterLayout FJS73AudioProcessor::createLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;

    p.push_back (std::make_unique<APF> (juce::ParameterID { "input", 1 }, "Input",
                 juce::NormalisableRange<float> (-20.f, 10.f, 0.5f), 0.f,
                 juce::AudioParameterFloatAttributes().withStringFromValueFunction (dbText)));

    p.push_back (std::make_unique<APF> (juce::ParameterID { "hfGain", 1 }, "HF Gain",
                 juce::NormalisableRange<float> (-16.f, 16.f, 0.5f), 0.f,
                 juce::AudioParameterFloatAttributes().withStringFromValueFunction (dbText)));

    p.push_back (std::make_unique<APF> (juce::ParameterID { "midGain", 1 }, "Mid Gain",
                 juce::NormalisableRange<float> (-18.f, 18.f, 0.5f), 0.f,
                 juce::AudioParameterFloatAttributes().withStringFromValueFunction (dbText)));

    p.push_back (std::make_unique<APC> (juce::ParameterID { "midFreq", 1 }, "Mid Freq",
                 juce::StringArray { "OFF", "360 Hz", "700 Hz", "1.6 kHz", "3.2 kHz", "4.8 kHz", "7.2 kHz" }, 3));

    p.push_back (std::make_unique<APF> (juce::ParameterID { "lfGain", 1 }, "LF Gain",
                 juce::NormalisableRange<float> (-16.f, 16.f, 0.5f), 0.f,
                 juce::AudioParameterFloatAttributes().withStringFromValueFunction (dbText)));

    p.push_back (std::make_unique<APC> (juce::ParameterID { "lfFreq", 1 }, "LF Freq",
                 juce::StringArray { "OFF", "35 Hz", "60 Hz", "110 Hz", "220 Hz" }, 3));

    p.push_back (std::make_unique<APC> (juce::ParameterID { "hpf", 1 }, "High Pass",
                 juce::StringArray { "OFF", "50 Hz", "80 Hz", "160 Hz", "300 Hz" }, 0));

    p.push_back (std::make_unique<APB> (juce::ParameterID { "phase", 1 }, "Phase", false));
    p.push_back (std::make_unique<APB> (juce::ParameterID { "eqIn", 1 }, "EQ In", true));

    p.push_back (std::make_unique<APF> (juce::ParameterID { "output", 1 }, "Output",
                 juce::NormalisableRange<float> (-12.f, 12.f, 0.1f), 0.f,
                 juce::AudioParameterFloatAttributes().withStringFromValueFunction (dbText)));

    return { p.begin(), p.end() };
}

//==============================================================================
FJS73AudioProcessor::FJS73AudioProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "STATE", createLayout())
{
    pInput   = apvts.getRawParameterValue ("input");
    pOutput  = apvts.getRawParameterValue ("output");
    pHfGain  = apvts.getRawParameterValue ("hfGain");
    pMidGain = apvts.getRawParameterValue ("midGain");
    pMidFreq = apvts.getRawParameterValue ("midFreq");
    pLfGain  = apvts.getRawParameterValue ("lfGain");
    pLfFreq  = apvts.getRawParameterValue ("lfFreq");
    pHpf     = apvts.getRawParameterValue ("hpf");
    pPhase   = apvts.getRawParameterValue ("phase");
    pEqIn    = apvts.getRawParameterValue ("eqIn");
}

bool FJS73AudioProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    const auto& in = l.getMainInputChannelSet();
    const auto& out = l.getMainOutputChannelSet();
    return in == out && (in == juce::AudioChannelSet::mono() || in == juce::AudioChannelSet::stereo());
}

void FJS73AudioProcessor::prepareToPlay (double sr, int)
{
    sampleRate = sr;
    for (auto& c : ch) c.reset();
    inGain.reset (sr, 0.02);
    outGain.reset (sr, 0.02);
    inGain.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (pInput->load()));
    outGain.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (pOutput->load()));
    firstUpdate = true;
    updateFilters();
}

void FJS73AudioProcessor::updateFilters()
{
    const float hf  = pHfGain->load();
    const float mid = pMidGain->load();
    const float lf  = pLfGain->load();
    const int   mf  = juce::jlimit (0, 6, (int) std::lround (pMidFreq->load()));
    const int   lff = juce::jlimit (0, 4, (int) std::lround (pLfFreq->load()));
    const int   hp  = juce::jlimit (0, 4, (int) std::lround (pHpf->load()));
    const bool  eq  = pEqIn->load() > 0.5f;

    if (! firstUpdate && hf == cHf && mid == cMid && lf == cLf
        && (float) mf == cMidF && (float) lff == cLfF && (float) hp == cHpf && eq == cEq)
        return;

    firstUpdate = false;
    cHf = hf; cMid = mid; cLf = lf; cMidF = (float) mf; cLfF = (float) lff; cHpf = (float) hp; cEq = eq;

    const double nyq = sampleRate * 0.45;

    for (auto& c : ch)
    {
        // HPF 18 dB/oct (1 polo + 2 polos), como el 1073
        if (hp == 0) { c.hpf2.makeIdentity(); c.hpf1.makeIdentity(); }
        else
        {
            const double f = juce::jmin ((double) hpfFreqs[(size_t) hp], nyq);
            c.hpf2.makeHighPass2 (sampleRate, f, 0.9);
            c.hpf1.makeHighPass1 (sampleRate, f);
        }

        // Shelf grave (35/60/110/220 Hz, +-16 dB)
        if (lff == 0 || std::abs (lf) < 0.01f) c.lowShelf.makeIdentity();
        else c.lowShelf.makeLowShelf (sampleRate, juce::jmin ((double) lowFreqs[(size_t) lff], nyq), lf, 0.6);

        // Campana media (360 Hz - 7.2 kHz, +-18 dB)
        if (mf == 0 || std::abs (mid) < 0.01f) c.midPeak.makeIdentity();
        else c.midPeak.makePeak (sampleRate, juce::jmin ((double) midFreqs[(size_t) mf], nyq), mid, 0.9);

        // Shelf agudo (12 kHz de "banda"; el codo está más abajo para que a 12k llegue casi al máximo) (+-16 dB)
        if (std::abs (hf) < 0.01f) c.highShelf.makeIdentity();
        else c.highShelf.makeHighShelf (sampleRate, juce::jmin (9000.0, nyq), hf, 0.6);
    }
}

void FJS73AudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int numCh = juce::jmin (buffer.getNumChannels(), 2);
    const int n = buffer.getNumSamples();

    updateFilters();

    const float inDb = pInput->load();
    inGain.setTargetValue (juce::Decibels::decibelsToGain (inDb));
    outGain.setTargetValue (juce::Decibels::decibelsToGain (pOutput->load()));

    const float polarity = pPhase->load() > 0.5f ? -1.0f : 1.0f;
    const bool eqOn = pEqIn->load() > 0.5f;

    // Cuanto más input, más "empuja" el transformador/preamp
    const float drive = juce::jmap (inDb, -20.f, 10.f, 0.f, 1.f);
    const float k = 1.0f + 0.9f * drive;
    const float bias = 0.06f;
    const float tb = std::tanh (bias);
    const float dcCoef = 1.0f - (2.0f * juce::MathConstants<float>::pi * 5.0f / (float) sampleRate);

    for (int i = 0; i < n; ++i)
    {
        const float g  = inGain.getNextValue();
        const float og = outGain.getNextValue();

        for (int c = 0; c < numCh; ++c)
        {
            auto& s = ch[(size_t) c];
            float* d = buffer.getWritePointer (c);

            float x = d[i] * g * polarity;

            // Etapa de entrada: saturación suave asimétrica (armónicos pares + impares)
            float y = (std::tanh (k * x + bias) - tb) / k;
            // bloqueador de DC por la asimetría
            const float dc = y - s.dcX + dcCoef * s.dcY;
            s.dcX = y; s.dcY = dc;
            y = dc;

            y = s.hpf1.process (s.hpf2.process (y));

            if (eqOn)
            {
                y = s.lowShelf.process (y);
                y = s.midPeak.process (y);
                y = s.highShelf.process (y);
            }

            d[i] = y * og;
        }
    }
}

//==============================================================================
juce::AudioProcessorEditor* FJS73AudioProcessor::createEditor() { return new FJS73Editor (*this); }

void FJS73AudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    if (auto xml = apvts.copyState().createXml())
        copyXmlToBinary (*xml, destData);
}

void FJS73AudioProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new FJS73AudioProcessor(); }
