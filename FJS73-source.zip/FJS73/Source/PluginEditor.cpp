#include "PluginEditor.h"

using namespace juce;

//==============================================================================
namespace
{
    Point<float> polar (Point<float> c, float rad, float r) { return { c.x + r * std::sin (rad), c.y - r * std::cos (rad) }; }
    Point<float> polarDeg (Point<float> c, float deg, float r) { return polar (c, degreesToRadians (deg), r); }

    Font labelFont (float h, bool bold = true)
    {
       #if JUCE_MAC
        return Font (FontOptions ("Helvetica Neue", h, bold ? Font::bold : Font::plain));
       #else
        return Font (FontOptions (h, bold ? Font::bold : Font::plain));
       #endif
    }

    const Colour labelCol { 0xffe6eaf0 };

    void drawLabel (Graphics& g, const String& text, Point<float> p, float h = 14.f, bool bold = true)
    {
        g.setFont (labelFont (h, bold));
        auto r = Rectangle<float> (70.f, h + 6.f).withCentre (p);
        g.setColour (Colours::black.withAlpha (0.55f));
        g.drawText (text, r.translated (0.8f, 1.0f), Justification::centred, false);
        g.setColour (labelCol);
        g.drawText (text, r, Justification::centred, false);
    }

    void drawDot (Graphics& g, Point<float> p, float r = 3.6f)
    {
        g.setColour (Colours::black.withAlpha (0.55f));
        g.fillEllipse (p.x - r + 0.9f, p.y - r + 1.3f, r * 2, r * 2);
        g.setGradientFill (ColourGradient (Colours::white.withAlpha (0.96f), p.x - r * 0.4f, p.y - r * 0.5f,
                                           Colour (0xff9ea6b0), p.x + r, p.y + r, true));
        g.fillEllipse (p.x - r, p.y - r, r * 2, r * 2);
    }

    void drawDots (Graphics& g, Point<float> c, float fromDeg, float toDeg, int count, float radius)
    {
        for (int i = 0; i < count; ++i)
            drawDot (g, polarDeg (c, fromDeg + (toDeg - fromDeg) * (float) i / (float) (count - 1), radius));
    }

    void strokeIcon (Graphics& g, const Path& p, Point<float> c)
    {
        Path q (p);
        q.applyTransform (AffineTransform::translation (c));
        g.setColour (Colours::black.withAlpha (0.5f));
        g.strokePath (q, PathStrokeType (2.4f, PathStrokeType::curved, PathStrokeType::rounded),
                      AffineTransform::translation (0.8f, 1.1f));
        g.setColour (labelCol);
        g.strokePath (q, PathStrokeType (2.4f, PathStrokeType::curved, PathStrokeType::rounded));
    }

    void drawIcons (Graphics& g)
    {
        // shelf agudos
        { Path p; p.startNewSubPath (-22, 7); p.lineTo (-10, 7); p.cubicTo (-3, 7, -4, -6, 3, -6); p.lineTo (20, -6);
          strokeIcon (g, p, { 348.f, 38.f }); }
        // campana
        { Path p; p.startNewSubPath (-22, 0); p.lineTo (-8, 0); p.addEllipse (-6.f, -6.f, 12.f, 12.f); p.startNewSubPath (8, 0); p.lineTo (22, 0);
          strokeIcon (g, p, { 537.f, 38.f }); }
        // shelf graves
        { Path p; p.startNewSubPath (-20, -6); p.lineTo (-3, -6); p.cubicTo (4, -6, 3, 7, 10, 7); p.lineTo (22, 7);
          strokeIcon (g, p, { 726.f, 38.f }); }
        // pasa-altos
        { Path p; p.startNewSubPath (-22, 7); p.cubicTo (-12, 7, -10, -6, -2, -6); p.lineTo (20, -6);
          strokeIcon (g, p, { 910.f, 38.f }); }
    }

    void drawScrew (Graphics& g, Point<float> c, float rot)
    {
        const float r = 12.f;
        Path p; p.addEllipse (c.x - r, c.y - r, 2 * r, 2 * r);
        DropShadow (Colours::white.withAlpha (0.10f), 1, { 0, 1 }).drawForPath (g, p);
        g.setGradientFill (ColourGradient (Colour (0xff4b525c), c.x - r * 0.5f, c.y - r * 0.6f,
                                           Colour (0xff0e1114), c.x + r, c.y + r, true));
        g.fillPath (p);
        g.setColour (Colours::black.withAlpha (0.8f));
        g.drawEllipse (c.x - r, c.y - r, 2 * r, 2 * r, 1.4f);
        g.setColour (Colours::black.withAlpha (0.9f));
        for (int k = 0; k < 2; ++k)
        {
            auto a = polar (c, rot + (float) k * MathConstants<float>::halfPi, 7.5f);
            auto b = polar (c, rot + (float) k * MathConstants<float>::halfPi + MathConstants<float>::pi, 7.5f);
            g.drawLine ({ a, b }, 2.2f);
        }
    }
}

//==============================================================================
HardwareKnob::HardwareKnob (Style s, Colour b, float cr, float sr)
    : style (s), base (b), capR (cr), skirtR (sr)
{
    if (style == Style::Ring) { ringOuterR = 66.f; ringInnerR = 47.f; }

    setSliderStyle (Slider::RotaryVerticalDrag);
    setTextBoxStyle (Slider::NoTextBox, true, 0, 0);
    setMouseDragSensitivity (170);
    setPopupDisplayEnabled (true, false, nullptr);
    setScrollWheelEnabled (true);
}

bool HardwareKnob::hitTest (int x, int y)
{
    auto c = getLocalBounds().toFloat().getCentre();
    float r = style == Style::Ring ? ringOuterR : jmax (capR * 1.25f, skirtR);
    return c.getDistanceFrom ({ (float) x, (float) y }) <= r;
}

void HardwareKnob::paint (Graphics& g)
{
    auto c = getLocalBounds().toFloat().getCentre();
    auto rp = getRotaryParameters();
    const float prop = (float) valueToProportionOfLength (getValue());
    const float ang = rp.startAngleRadians + prop * (rp.endAngleRadians - rp.startAngleRadians);

    if (style == Style::Ring)
    {
        paintRing (g, c, ang);
        return;
    }

    if (skirtR > 0.f) paintSkirt (g, c);
    paintCap (g, c, ang);
}

void HardwareKnob::paintSkirt (Graphics& g, Point<float> c)
{
    Path p; p.addEllipse (c.x - skirtR, c.y - skirtR, skirtR * 2, skirtR * 2);
    DropShadow (Colours::black.withAlpha (0.7f), 14, { 2, 6 }).drawForPath (g, p);

    g.setGradientFill (ColourGradient (Colour (0xff7b8189), c.x - skirtR * 0.55f, c.y - skirtR * 0.75f,
                                       Colour (0xff1f2328), c.x + skirtR * 0.7f, c.y + skirtR * 0.95f, false));
    g.fillPath (p);

    // anillos concéntricos tipo metal torneado
    for (float r = skirtR - 5.f; r > capR + 6.f; r -= 2.5f)
    {
        g.setColour (((int) r % 2 == 0 ? Colours::white : Colours::black).withAlpha (0.045f));
        g.drawEllipse (c.x - r, c.y - r, r * 2, r * 2, 1.f);
    }

    // sombra interior donde apoya la perilla
    {
        const float rr = capR + 20.f;
        ColourGradient gr (Colours::black.withAlpha (0.65f), c, Colours::transparentBlack, c.translated (rr, 0.f), true);
        gr.addColour ((double) (capR / rr), Colours::black.withAlpha (0.65f));
        g.setGradientFill (gr);
        g.fillEllipse (c.x - rr, c.y - rr, rr * 2, rr * 2);
    }

    // bisel exterior: luz arriba-izquierda, sombra abajo-derecha
    g.setGradientFill (ColourGradient (Colours::white.withAlpha (0.55f), c.x - skirtR * 0.7f, c.y - skirtR * 0.7f,
                                       Colours::black.withAlpha (0.8f), c.x + skirtR * 0.7f, c.y + skirtR * 0.7f, false));
    g.drawEllipse (c.x - skirtR + 1.f, c.y - skirtR + 1.f, skirtR * 2 - 2.f, skirtR * 2 - 2.f, 1.8f);
}

void HardwareKnob::paintCap (Graphics& g, Point<float> c, float angle)
{
    // sombra proyectada
    {
        Path sp; sp.addEllipse (c.x - capR, c.y - capR, capR * 2, capR * 2);
        DropShadow (Colours::black.withAlpha (style == Style::Silver ? 0.75f : 0.8f),
                    style == Style::Silver ? 8 : 12, { 2, style == Style::Silver ? 4 : 6 }).drawForPath (g, sp);
    }

    // aleta/puntero de las perillas rojas y azules
    if (style == Style::Lug)
    {
        const float len = capR * 1.3f, w = capR * 0.62f;
        Path lug; lug.addRoundedRectangle (-w / 2, -len, w, len, 7.f);
        lug.applyTransform (AffineTransform::rotation (angle).translated (c));
        DropShadow (Colours::black.withAlpha (0.8f), 9, { 2, 5 }).drawForPath (g, lug);
        g.setGradientFill (ColourGradient (base.brighter (0.35f), c.x - capR * 0.6f, c.y - capR * 0.8f,
                                           base.darker (0.75f), c.x + capR * 0.9f, c.y + capR * 1.2f, false));
        g.fillPath (lug);
        g.setColour (Colours::black.withAlpha (0.55f));
        g.strokePath (lug, PathStrokeType (1.f));
    }

    // pared lateral del cilindro
    g.setGradientFill (ColourGradient (base.brighter (0.25f), c.x, c.y - capR, base.darker (0.8f), c.x, c.y + capR, false));
    g.fillEllipse (c.x - capR, c.y - capR, capR * 2, capR * 2);

    // moleteado
    if (style == Style::Knurled || style == Style::Silver)
    {
        const int n = style == Style::Silver ? 36 : 54;
        for (int i = 0; i < n; ++i)
        {
            const float a = MathConstants<float>::twoPi * (float) i / (float) n;
            const float inner = capR - (style == Style::Silver ? 2.5f : 4.5f);
            g.setColour (Colours::black.withAlpha (0.42f));
            g.drawLine ({ polar (c, a, inner), polar (c, a, capR) }, 1.3f);
            g.setColour (Colours::white.withAlpha (0.16f));
            g.drawLine ({ polar (c, a + MathConstants<float>::pi / (float) n, inner), polar (c, a + MathConstants<float>::pi / (float) n, capR) }, 1.f);
        }
    }

    // tapa superior
    const float tr = capR - (style == Style::Knurled ? 4.f : 3.f);
    g.setGradientFill (ColourGradient (base.brighter (0.6f), c.x - tr * 0.45f, c.y - tr * 0.55f,
                                       base.darker (0.45f), c.x + tr * 0.9f, c.y + tr * 1.0f, true));
    g.fillEllipse (c.x - tr, c.y - tr, tr * 2, tr * 2);

    // anillos de torneado en la tapa
    if (style != Style::Lug)
        for (float r = tr - 2.f; r > 4.f; r -= 3.f)
        {
            g.setColour (Colours::white.withAlpha (0.035f));
            g.drawEllipse (c.x - r, c.y - r, r * 2, r * 2, 1.f);
        }

    // brillo especular
    {
        ColourGradient spec (Colours::white.withAlpha (0.30f), c.x - tr * 0.35f, c.y - tr * 0.45f,
                             Colours::transparentWhite, c.x + tr * 0.35f, c.y + tr * 0.3f, true);
        g.setGradientFill (spec);
        g.fillEllipse (c.x - tr, c.y - tr, tr * 2, tr * 2);
    }

    // bisel
    g.setGradientFill (ColourGradient (Colours::white.withAlpha (0.55f), c.x - tr * 0.7f, c.y - tr * 0.7f,
                                       Colours::black.withAlpha (0.6f), c.x + tr * 0.7f, c.y + tr * 0.7f, false));
    g.drawEllipse (c.x - tr, c.y - tr, tr * 2, tr * 2, 1.3f);
    g.setColour (Colours::black.withAlpha (0.65f));
    g.drawEllipse (c.x - capR, c.y - capR, capR * 2, capR * 2, 1.f);

    // puntero
    if (style == Style::Silver)
    {
        g.setColour (Colour (0xff23262a));
        g.drawLine ({ polar (c, angle, tr * 0.25f), polar (c, angle, tr * 0.9f) }, 2.4f);
    }
    else
    {
        const float r0 = style == Style::Lug ? capR * 0.62f : capR * 0.3f;
        const float r1 = style == Style::Lug ? capR * 1.18f : capR * 0.88f;
        const float w  = style == Style::Lug ? 3.6f : 2.6f;
        g.setColour (Colours::black.withAlpha (0.55f));
        g.drawLine ({ polar (c, angle, r0).translated (0.8f, 1.2f), polar (c, angle, r1).translated (0.8f, 1.2f) }, w);
        g.setColour (Colours::white.withAlpha (0.97f));
        g.drawLine ({ polar (c, angle, r0), polar (c, angle, r1) }, w);
    }
}

void HardwareKnob::paintRing (Graphics& g, Point<float> c, float angle)
{
    const float R = ringOuterR, r = ringInnerR;

    Path outer; outer.addEllipse (c.x - R, c.y - R, R * 2, R * 2);
    DropShadow (Colours::black.withAlpha (0.75f), 14, { 2, 7 }).drawForPath (g, outer);

    // hueco oscuro donde asoma la perilla interior
    g.setColour (Colour (0xff171b20));
    g.fillEllipse (c.x - r, c.y - r, r * 2, r * 2);
    g.setGradientFill (ColourGradient (Colours::black.withAlpha (0.8f), c.x, c.y - r, Colours::transparentBlack, c.x, c.y + r * 0.2f, false));
    g.fillEllipse (c.x - r, c.y - r, r * 2, r * 2);

    // cuerpo del anillo
    Path ring; ring.addEllipse (c.x - R, c.y - R, R * 2, R * 2); ring.addEllipse (c.x - r, c.y - r, r * 2, r * 2);
    ring.setUsingNonZeroWinding (false);
    g.setGradientFill (ColourGradient (base.brighter (0.15f), c.x - R * 0.6f, c.y - R * 0.8f,
                                       base.darker (0.55f), c.x + R * 0.8f, c.y + R, false));
    g.fillPath (ring);

    // moleteado del borde exterior
    const int n = 72;
    for (int i = 0; i < n; ++i)
    {
        const float a = MathConstants<float>::twoPi * (float) i / (float) n;
        g.setColour (Colours::black.withAlpha (0.30f));
        g.drawLine ({ polar (c, a, R - 7.f), polar (c, a, R) }, 1.4f);
        const float a2 = a + MathConstants<float>::pi / (float) n;
        g.setColour (Colours::white.withAlpha (0.28f));
        g.drawLine ({ polar (c, a2, R - 7.f), polar (c, a2, R) }, 1.f);
    }

    // brillo de la cara superior
    g.setGradientFill (ColourGradient (Colours::white.withAlpha (0.22f), c.x - R * 0.5f, c.y - R * 0.6f,
                                       Colours::transparentWhite, c.x + R * 0.2f, c.y + R * 0.2f, true));
    g.fillPath (ring);

    // biseles
    g.setGradientFill (ColourGradient (Colours::white.withAlpha (0.7f), c.x - R * 0.7f, c.y - R * 0.7f,
                                       Colours::black.withAlpha (0.6f), c.x + R * 0.7f, c.y + R * 0.7f, false));
    g.drawEllipse (c.x - R + 0.5f, c.y - R + 0.5f, R * 2 - 1.f, R * 2 - 1.f, 1.3f);
    g.setGradientFill (ColourGradient (Colours::black.withAlpha (0.7f), c.x - r * 0.7f, c.y - r * 0.7f,
                                       Colours::white.withAlpha (0.4f), c.x + r * 0.7f, c.y + r * 0.7f, false));
    g.drawEllipse (c.x - r, c.y - r, r * 2, r * 2, 1.6f);

    // marca del selector
    g.setColour (Colour (0xff2a2a28).withAlpha (0.85f));
    g.drawLine ({ polar (c, angle, r + 4.f), polar (c, angle, R - 10.f) }, 3.0f);
}

//==============================================================================
void KeyButton::paintButton (Graphics& g, bool /*over*/, bool /*down*/)
{
    auto b = getLocalBounds().toFloat().reduced (2.f);
    const bool on = getToggleState();
    const bool phase = kind == Kind::Phase;
    const float off = on ? 2.0f : 0.f;

    Colour top, bot;
    if (phase) { top = on ? Colour (0xfff4ecc2) : Colour (0xffece6d0); bot = on ? Colour (0xffd8cd96) : Colour (0xffc9c2a6); }
    else       { top = on ? Colour (0xff55554f) : Colour (0xff4a4a46); bot = Colour (0xff22221f); }

    auto cap = b.translated (0.f, off);

    if (! on)
    {
        Path sp; sp.addRoundedRectangle (cap, 4.f);
        DropShadow (Colours::black.withAlpha (0.7f), 7, { 0, 4 }).drawForPath (g, sp);
    }

    g.setGradientFill (ColourGradient (top, cap.getX(), cap.getY(), bot, cap.getX(), cap.getBottom(), false));
    g.fillRoundedRectangle (cap, 4.f);

    // reborde luminoso arriba y oscuro abajo
    g.setColour (Colours::white.withAlpha (phase ? 0.65f : 0.22f));
    g.drawLine (cap.getX() + 4.f, cap.getY() + 1.f, cap.getRight() - 4.f, cap.getY() + 1.f, 1.2f);
    g.setColour (Colours::black.withAlpha (0.55f));
    g.drawRoundedRectangle (cap, 4.f, 1.2f);

    if (phase)
    {
        g.setColour (Colour (0xff2b2a24));
        g.setFont (labelFont (30.f, true));
        g.drawText (String::fromUTF8 ("\xc3\x98"), cap, Justification::centred, false);
    }
    else
    {
        g.setColour (on ? Colour (0xfff2ead0) : Colour (0xff7d7d76));
        g.setFont (labelFont (22.f, true));
        g.drawText ("EQ", cap, Justification::centred, false);
    }
}

//==============================================================================
Panel::Panel (AudioProcessorValueTreeState& s)
{
    setSize (ui::W, ui::H);

    // textura sutil de grano (se genera una sola vez)
    noise = Image (Image::ARGB, ui::W, ui::H, true);
    {
        Random rnd (7);
        Image::BitmapData bd (noise, Image::BitmapData::writeOnly);
        for (int y = 0; y < ui::H; ++y)
            for (int x = 0; x < ui::W; ++x)
            {
                const bool light = rnd.nextBool();
                const float a = rnd.nextFloat() * 0.07f;
                bd.setPixelColour (x, y, (light ? Colours::white : Colours::black).withAlpha (a));
            }
    }

    auto place = [this] (HardwareKnob& k, Point<float> centre)
    {
        const int sz = k.sizeForRadius();
        k.setBounds (Rectangle<int> (sz, sz).withCentre (centre.toInt()));
        addAndMakeVisible (k);
    };

    const auto cIn  = Point<float> (160.f, 125.f);
    const auto cHf  = Point<float> (348.f, 128.f);
    const auto cMid = Point<float> (537.f, 127.f);
    const auto cLf  = Point<float> (726.f, 127.f);
    const auto cHpf = Point<float> (910.f, 125.f);

    place (input, cIn);
    place (hfGain, cHf);
    place (midFreq, cMid);
    place (midGain, cMid);
    place (lfFreq, cLf);
    place (lfGain, cLf);
    place (hpf, cHpf);
    place (output, { 1122.f, 122.f });

    auto rot = [] (HardwareKnob& k, float a0, float a1)
    {
        k.setRotaryParameters ({ degreesToRadians (a0), degreesToRadians (a1), true });
    };
    rot (input, 50.f, 245.f);
    rot (hfGain, 60.f, 300.f);
    rot (midGain, 60.f, 300.f);
    rot (lfGain, 60.f, 300.f);
    rot (midFreq, 90.f, 270.f);
    rot (lfFreq, 90.f, 210.f);
    rot (hpf, 90.f, 210.f);
    rot (output, 225.f, 495.f);

    addAndMakeVisible (phaseBtn);
    addAndMakeVisible (eqBtn);
    phaseBtn.setBounds (1025, 40, 42, 82);
    eqBtn.setBounds (1025, 123, 42, 79);

    aIn   = std::make_unique<SA> (s, "input", input);
    aHf   = std::make_unique<SA> (s, "hfGain", hfGain);
    aMidF = std::make_unique<SA> (s, "midFreq", midFreq);
    aMidG = std::make_unique<SA> (s, "midGain", midGain);
    aLfF  = std::make_unique<SA> (s, "lfFreq", lfFreq);
    aLfG  = std::make_unique<SA> (s, "lfGain", lfGain);
    aHpf  = std::make_unique<SA> (s, "hpf", hpf);
    aOut  = std::make_unique<SA> (s, "output", output);
    aPhase = std::make_unique<BA> (s, "phase", phaseBtn);
    aEq    = std::make_unique<BA> (s, "eqIn", eqBtn);
}

void Panel::paint (Graphics& g)
{
    const float W = (float) ui::W, H = (float) ui::H;

    // chapa azul-grisácea
    g.setGradientFill (ColourGradient (Colour (0xff36424f), 0.f, 0.f, Colour (0xff222a34), 0.f, H, false));
    g.fillAll();
    g.setGradientFill (ColourGradient (Colours::transparentBlack, W * 0.5f, H * 0.5f,
                                       Colours::black.withAlpha (0.42f), 0.f, 0.f, true));
    g.fillAll();
    g.drawImageAt (noise, 0, 0);

    // bordes del frente
    g.setColour (Colours::black.withAlpha (0.8f));
    g.drawRect (0.f, 0.f, W, H, 2.f);
    g.setColour (Colours::white.withAlpha (0.10f));
    g.drawRect (2.f, 2.f, W - 4.f, H - 4.f, 1.f);

    // tornillos
    drawScrew (g, { 28.f, 42.f }, 0.5f);
    drawScrew (g, { 1124.f, 42.f }, 1.1f);
    drawScrew (g, { 28.f, 204.f }, 2.0f);
    drawScrew (g, { 1124.f, 204.f }, 0.2f);

    // logo
    {
        const Point<float> c (72.f, 38.f);
        g.setColour (Colours::black.withAlpha (0.55f));
        g.drawEllipse (c.x - 17.f + 0.8f, c.y - 17.f + 1.1f, 34.f, 34.f, 2.4f);
        g.setColour (labelCol);
        g.drawEllipse (c.x - 17.f, c.y - 17.f, 34.f, 34.f, 2.4f);
        Path z; z.startNewSubPath (-11, 6); z.lineTo (-5, 6); z.lineTo (-1, -9); z.lineTo (4, 9); z.lineTo (8, -3); z.lineTo (12, -3);
        z.applyTransform (AffineTransform::translation (c));
        g.setColour (labelCol);
        g.strokePath (z, PathStrokeType (2.6f, PathStrokeType::mitered, PathStrokeType::butt));
    }

    drawIcons (g);

    const Point<float> cIn (160.f, 125.f), cHf (348.f, 128.f), cMid (537.f, 127.f), cLf (726.f, 127.f), cHpf (910.f, 125.f);

    // ---- INPUT
    drawDots (g, cIn, 50.f, 245.f, 13, 78.f);
    drawLabel (g, "LINE", { 225.f, 36.f }, 15.f);
    drawLabel (g, "-20", polarDeg (cIn, 50.f, 98.f), 13.f);
    drawLabel (g, "10",  polarDeg (cIn, 115.f, 96.f), 13.f);
    drawLabel (g, "0",   { cIn.x, 213.f }, 13.f);
    drawLabel (g, "+10", polarDeg (cIn, 248.f, 98.f), 13.f);
    drawLabel (g, "dB",  { cIn.x, 232.f }, 14.f);

    // ---- HF SHELF (12 kHz)
    drawDots (g, cHf, 60.f, 300.f, 13, 76.f);
    drawLabel (g, "+", polarDeg (cHf, 312.f, 94.f), 18.f);
    drawLabel (g, "-", polarDeg (cHf, 48.f, 94.f), 18.f);
    drawLabel (g, "0", { cHf.x, 207.f }, 13.f);

    // ---- MID
    drawDots (g, cMid, 60.f, 300.f, 13, 79.f);
    drawLabel (g, "+", polarDeg (cMid, 312.f, 98.f), 18.f);
    drawLabel (g, "-", polarDeg (cMid, 48.f, 98.f), 18.f);
    {
        const char* t[] = { "OFF", "0.36", "0.7", "1.6", "3.2", "4.8", "7.2" };
        for (int i = 0; i < 7; ++i)
        {
            if (i == 3) continue;
            drawLabel (g, t[i], polarDeg (cMid, 90.f + 30.f * (float) i, i == 0 ? 106.f : 96.f), 13.f);
        }
        drawLabel (g, "0", { cMid.x, 205.f }, 13.f);
        drawLabel (g, "1.6", { cMid.x, 217.f }, 13.f);
        drawLabel (g, "KHz", { cMid.x, 233.f }, 14.f);
    }

    // ---- LOW
    drawDots (g, cLf, 60.f, 300.f, 13, 79.f);
    drawLabel (g, "+", polarDeg (cLf, 312.f, 98.f), 18.f);
    drawLabel (g, "-", polarDeg (cLf, 48.f, 98.f), 18.f);
    {
        const char* t[] = { "OFF", "35", "60", "110", "220" };
        for (int i = 0; i < 5; ++i)
        {
            if (i == 3) continue;
            drawLabel (g, t[i], polarDeg (cLf, 90.f + 30.f * (float) i, i == 0 ? 106.f : 96.f), 13.f);
        }
        drawLabel (g, "0", { cLf.x, 205.f }, 13.f);
        drawLabel (g, "110", { cLf.x, 217.f }, 13.f);
        drawLabel (g, "Hz", { cLf.x, 233.f }, 14.f);
    }

    // ---- HPF
    {
        const char* t[] = { "OFF", "50", "80", "160", "300" };
        for (int i = 0; i < 5; ++i)
        {
            if (i == 3) continue;
            drawLabel (g, t[i], polarDeg (cHpf, 90.f + 30.f * (float) i, i == 0 ? 88.f : 86.f), 13.f);
        }
        drawLabel (g, "160", { cHpf.x, 214.f }, 13.f);
        drawLabel (g, "Hz", { cHpf.x, 233.f }, 14.f);
    }

    // ---- recuadro de los pulsadores
    {
        auto r = Rectangle<float> (1020.f, 36.f, 52.f, 172.f);
        g.setColour (Colour (0xff0e1115));
        g.fillRoundedRectangle (r, 6.f);
        g.setGradientFill (ColourGradient (Colours::black, r.getX(), r.getY(), Colours::white.withAlpha (0.25f), r.getX(), r.getBottom(), false));
        g.drawRoundedRectangle (r, 6.f, 1.6f);
    }

    // ---- texto de modelo
    drawLabel (g, "FJS-73", { 1018.f, 229.f }, 14.f);
    {
        auto r = Rectangle<float> (1060.f, 219.f, 60.f, 20.f);
        g.setColour (labelCol);
        g.drawRect (r, 1.2f);
        g.setFont (labelFont (12.f, true));
        g.drawText ("ANALOG", r, Justification::centred, false);
    }
}

//==============================================================================
FJS73Editor::FJS73Editor (FJS73AudioProcessor& p) : AudioProcessorEditor (&p), panel (p.apvts)
{
    addAndMakeVisible (panel);
    setResizable (true, true);
    setResizeLimits (ui::W / 2, ui::H / 2, ui::W * 2, ui::H * 2);
    getConstrainer()->setFixedAspectRatio ((double) ui::W / (double) ui::H);
    setSize (ui::W, ui::H);
}

void FJS73Editor::resized()
{
    panel.setTransform (AffineTransform::scale ((float) getWidth() / (float) ui::W));
    panel.setBounds (0, 0, ui::W, ui::H);
}
