#!/bin/bash
# Compila FJS-73 (AU + VST3 + Standalone) en tu Mac y los instala en ~/Library/Audio/Plug-Ins
set -e
cd "$(dirname "$0")"

command -v cmake >/dev/null || { echo "Falta CMake: brew install cmake"; exit 1; }
xcode-select -p >/dev/null 2>&1 || { echo "Falta Xcode Command Line Tools: xcode-select --install"; exit 1; }

cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release -j"$(sysctl -n hw.ncpu)"

# Firma ad-hoc (necesaria en Apple Silicon para que los hosts carguen el plugin)
for f in "$HOME/Library/Audio/Plug-Ins/Components/FJS-73.component" "$HOME/Library/Audio/Plug-Ins/VST3/FJS-73.vst3"; do
  [ -e "$f" ] && codesign --force --deep -s - "$f"
done

killall -9 AudioComponentRegistrar 2>/dev/null || true
echo ""
echo "Listo. Reiniciá tu DAW y buscá 'FJS-73' (FJS Audio)."
echo "AU:   ~/Library/Audio/Plug-Ins/Components/FJS-73.component"
echo "VST3: ~/Library/Audio/Plug-Ins/VST3/FJS-73.vst3"
