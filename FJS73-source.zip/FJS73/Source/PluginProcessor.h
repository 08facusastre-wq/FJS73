#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <cmath>

//==============================================================================
// Biquad mínimo (RBJ cookbook), sin alocaciones -> seguro en el hilo de audio
struct Biquad
{
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
    float z1 = 0, z2 = 0;

    void reset() noexcept { z1 = z2 = 0; }

    inline float process (float x) noexcept
    {
        const float y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }

    void set (double B0, double B1, double B2, double A0, double A1, double A2) noexcept
    {
        const double inv = 1.0 / A0;
        b0 = (float) (B0 * inv); b1 = (float) (B1 * inv); b2 = (float) (B2 * inv);
        a1 = (float) (A1 * inv); a2 = (float) (A2 * inv);
    }

    void makeIdentity() noexcept { b0 = 1; b1 = b2 = a1 = a2 = 0; }

    void makePeak (double sr, double f, double gainDb, double q) noexcept
    {
        const double A = std::pow (10.0, gainDb / 40.0);
        const double w = 2.0 * juce::MathConstants<double>::pi * f / sr;
        const double c = std::cos (w), al = std::sin (w) / (2.0 * q);
        set (1 + al * A, -2 * c, 1 - al * A, 1 + al / A, -2 * c, 1 - al / A);
    }

    void makeLowShelf (double sr, double f, double gainDb, double slope) noexcept
    {
        const double A = std::pow (10.0, gainDb / 40.0);
        const double w = 2.0 * juce::MathConstants<double>::pi * f / sr;
        const double c = std::cos (w), s = std::sin (w);
        const double al = s / 2.0 * std::sqrt ((A + 1 / A) * (1 / slope - 1) + 2);
        const double t = 2 * std::sqrt (A) * al;
        set (A * ((A + 1) - (A - 1) * c + t),
             2 * A * ((A - 1) - (A + 1) * c),
             A * ((A + 1) - (A - 1) * c - t),
             (A + 1) + (A - 1) * c + t,
             -2 * ((A - 1) + (A + 1) * c),
             (A + 1) + (A - 1) * c - t);
    }

    void makeHighShelf (double sr, double f, double gainDb, double slope) noexcept
    {
        const double A = std::pow (10.0, gainDb / 40.0);
        const double w = 2.0 * juce::MathConstants<double>::pi * f / sr;
        const double c = std::cos (w), s = std::sin (w);
        const double al = s / 2.0 * std::sqrt ((A + 1 / A) * (1 / slope - 1) + 2);
        const double t = 2 * std::sqrt (A) * al;
        set (A * ((A + 1) + (A - 1) * c + t),
             -2 * A * ((A - 1) + (A + 1) * c),
             A * ((A + 1) + (A - 1) * c - t),
             (A + 1) - (A - 1) * c + t,
             2 * ((A - 1) - (A + 1) * c),
             (A + 1) - (A - 1) * c - t);
    }

    void makeHighPass2 (double sr, double f, double q = 0.7071) noexcept
    {
        const double w = 2.0 * juce::MathConstants<double>::pi * f / sr;
        const double c = std::cos (w), al = std::sin (w) / (2.0 * q);
        set ((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al);
    }

    void makeHighPass1 (double sr, double f) noexcept
    {
        const double k = std::tan (juce::MathConstants<double>::pi * f / sr);
        set (1.0, -1.0, 0.0, 1.0 + k, k - 1.0, 0.0);
    }
};

//==============================================================================
class FJS73AudioProcessor : public juce::AudioProcessor
{
public:
    FJS73AudioProcessor();
    ~FJS73AudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "FJS-73"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;

    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

    // Frecuencias de los selectores (índice 0 = OFF)
    static constexpr std::array<float, 7> midFreqs { 0.f, 360.f, 700.f, 1600.f, 3200.f, 4800.f, 7200.f };
    static constexpr std::array<float, 5> lowFreqs { 0.f, 35.f, 60.f, 110.f, 220.f };
    // HPF: OFF, 50, 80, 160, 300
    static constexpr std::array<float, 5> hpfFreqs { 0.f, 50.f, 80.f, 160.f, 300.f };

private:
    void updateFilters();

    double sampleRate = 44100.0;

    struct ChannelState
    {
        Biquad hpf2, hpf1, lowShelf, midPeak, highShelf;
        float dcX = 0.f, dcY = 0.f;
        void reset() { hpf2.reset(); hpf1.reset(); lowShelf.reset(); midPeak.reset(); highShelf.reset(); dcX = dcY = 0.f; }
    };
    std::array<ChannelState, 2> ch;

    juce::SmoothedValue<float> inGain, outGain;

    std::atomic<float>* pInput = nullptr;   std::atomic<float>* pOutput = nullptr;
    std::atomic<float>* pHfGain = nullptr;  std::atomic<float>* pMidGain = nullptr;
    std::atomic<float>* pLfGain = nullptr;  std::atomic<float>* pMidFreq = nullptr;
    std::atomic<float>* pLfFreq = nullptr;  std::atomic<float>* pHpf = nullptr;
    std::atomic<float>* pPhase = nullptr;   std::atomic<float>* pEqIn = nullptr;

    // cache para recalcular coeficientes solo si algo cambió
    float cHf = 1e9f, cMid = 1e9f, cLf = 1e9f, cMidF = -1, cLfF = -1, cHpf = -1;
    bool cEq = true;
    bool firstUpdate = true;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (FJS73AudioProcessor)
};
